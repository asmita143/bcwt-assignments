'use-strict';

const ballon = document.querySelector('p');
let initialballonSize = 10;
let ballonSize=initialballonSize;
let ballonSizeInPX;

window.addEventListener("keyup", event => {
    if (event.key == "ArrowUp") {
        if(ballonSize<=100){  
            ballonSize += (ballonSize*0.1);
            ballonSizeInPX = ballonSize+"px";
            console.log(ballonSizeInPX)
            if(ballonSize >= 100){
              document.getElementById('p').innerHTML = "💥";
              removeEventListener("ArrowUp");
            }else{
              balloonSize();
            }}
      
    }
    if (event.key == "ArrowDown") {
        if(ballonSize<=100){
            ballonSize -= (ballonSize*0.1);
            ballonSizeInPX = ballonSize+"px"
            console.log("Decrease:" +ballonSizeInPX)
            if(ballonSize >= 100){
              removeEventListener("ArrowDown");
            }else{
              balloonSize();
            }
        
          }
  }
});


function balloonSize(){
    ballon.style.fontSize = ballonSizeInPX;
  }
